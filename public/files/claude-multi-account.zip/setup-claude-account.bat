@echo off
rem VS Code profile + Claude Code account setup.
rem Usage: double-click (asks profile name), or drag project folders onto this file.
setlocal
set "PS=pwsh"
where pwsh >nul 2>nul || set "PS=powershell"
%PS% -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup-claude-account.ps1" %*
echo.
pause
