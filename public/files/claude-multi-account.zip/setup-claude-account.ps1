﻿# VS Code 프로필 하나 = Claude Code 계정 하나
#  - 프로필 영문명을 받아 VS Code 프로필을 만들고(없으면) Claude Code 확장을 설치한다
#  - 그 프로필 사용자 설정에 CLAUDE_CONFIG_DIR = %USERPROFILE%\.claude-<이름> 을 넣는다
#    (.vscode/settings.json 은 machine 범위라 무시되므로 X)
#  - 인자로 받은 폴더들을 그 프로필로 연다 (VS Code 가 폴더-프로필 연결을 기억함)
param(
    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]]$Folders = @(),
    [string]$ProfileName = '',
    [string]$ConfigDir = ''
)
$ErrorActionPreference = 'Stop'

# --- 0. 프로필 이름 입력 ---
while ($ProfileName -notmatch '^[A-Za-z0-9_-]+$') {
    if ($ProfileName) { Write-Host '  영문/숫자/-/_ 만 쓸 수 있습니다.' }
    $ProfileName = (Read-Host '프로필 영문명 (예: personal, outsource)').Trim()
}
if (-not $ConfigDir) { $ConfigDir = Join-Path $HOME ".claude-$ProfileName" }
Write-Host "프로필: $ProfileName  /  Claude 설정 폴더: $ConfigDir"
Write-Host ''

$userDir = Join-Path $env:APPDATA 'Code\User'
$storage = Join-Path $userDir 'globalStorage\storage.json'

# --- code 명령 찾기 ---
$code = (Get-Command code.cmd -ErrorAction SilentlyContinue).Source
if (-not $code) {
    foreach ($c in @("$env:LOCALAPPDATA\Programs\Microsoft VS Code\bin\code.cmd",
                     "$env:ProgramFiles\Microsoft VS Code\bin\code.cmd")) {
        if (Test-Path $c) { $code = $c; break }
    }
}
if (-not $code) { throw 'VS Code(code 명령)를 찾지 못했습니다.' }

function Get-ProfileLocation {
    if (-not (Test-Path $storage)) { return $null }
    $s = [IO.File]::ReadAllText($storage) | ConvertFrom-Json
    ($s.userDataProfiles | Where-Object { $_.name -eq $ProfileName } | Select-Object -First 1).location
}

# --- 1. 프로필 확인 / 생성 ---
$loc = Get-ProfileLocation
if (-not $loc) {
    Write-Host "[1] '$ProfileName' 프로필이 없어 새로 만듭니다 (새 VS Code 창이 열립니다)..."
    & $code --profile $ProfileName --new-window | Out-Null
    for ($i = 0; $i -lt 30 -and -not $loc; $i++) { Start-Sleep 1; $loc = Get-ProfileLocation }
    if (-not $loc) { throw '프로필 생성을 확인하지 못했습니다. 열린 창을 닫고 다시 실행해 주세요.' }
} else {
    Write-Host "[1] '$ProfileName' 프로필 있음 ($loc)"
}
$profDir = Join-Path $userDir "profiles\$loc"
New-Item -ItemType Directory -Force $profDir | Out-Null

# --- 2. Claude Code 확장 ---
$extJson = Join-Path $profDir 'extensions.json'
if ((Test-Path $extJson) -and (Select-String -Path $extJson -Pattern 'anthropic.claude-code' -Quiet)) {
    Write-Host '[2] Claude Code 확장 설치되어 있음'
} else {
    Write-Host '[2] Claude Code 확장 설치...'
    & $code --profile $ProfileName --install-extension anthropic.claude-code | Out-Host
}

# --- 3. 프로필 사용자 설정에 CLAUDE_CONFIG_DIR ---
$settings = Join-Path $profDir 'settings.json'
$jsonPath = $ConfigDir -replace '\\', '\\'
$entry = @"
    "claudeCode.environmentVariables": [
        { "name": "CLAUDE_CONFIG_DIR", "value": "$jsonPath" }
    ]
"@
$text = if (Test-Path $settings) { [IO.File]::ReadAllText($settings) } else { '' }

if ($text -match 'claudeCode\.environmentVariables') {
    Write-Host '[3] 이미 claudeCode.environmentVariables 가 있어 건드리지 않습니다:'
    Write-Host "    $settings"
} else {
    if ($text.Trim() -eq '') {
        $new = "{`n$entry`n}`n"
    } else {
        Copy-Item $settings "$settings.bak" -Force
        $end = $text.LastIndexOf('}')
        $before = $text.Substring(0, $end).TrimEnd()
        $sep = if ($before.EndsWith('{') -or $before.EndsWith(',')) { '' } else { ',' }
        $new = $before + $sep + "`n" + $entry + "`n" + $text.Substring($end)
    }
    [IO.File]::WriteAllText($settings, $new, (New-Object Text.UTF8Encoding $false))
    Write-Host "[3] 설정 추가: CLAUDE_CONFIG_DIR = $ConfigDir"
}

# --- 4. 폴더를 이 프로필로 열기 ---
foreach ($f in $Folders) {
    if (Test-Path $f -PathType Container) {
        Write-Host "[4] '$ProfileName' 프로필로 열기: $f"
        & $code --profile $ProfileName $f | Out-Null
    } else {
        Write-Host "[4] 폴더가 아니어서 건너뜀: $f"
    }
}

Write-Host ''
Write-Host "완료. '$ProfileName' 프로필 창에서:"
Write-Host '  1) Ctrl+Shift+P > Developer: Reload Window (이미 열려 있던 창이면)'
Write-Host '  2) Claude 패널에서 /login  ->  이 프로필에 쓸 계정'
Write-Host '  3) /status 로 확인'
